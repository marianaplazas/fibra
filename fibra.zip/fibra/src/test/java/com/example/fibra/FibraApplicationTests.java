package com.example.fibra;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FibraApplicationTests {

	@Test
	void contextLoads() {
	}

}
